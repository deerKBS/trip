const config = {
  darkMode: false,
  mainTemplate: 'lightMode',
};

export default config;
